#!/bin/bash

for k in L I N U X
do
	echo -n	"$k"
done
echo
